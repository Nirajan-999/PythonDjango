# recaptchaAuthentication
User Authentication system with reCaptcha using django.

## INSTALLATION::
`Run Command: pip install -r requirements.txt`
After complete,

`Run Command: python manage.py runserver`
This will run the server.

`Type 127.0.0.1:8000 in browser and proceed to login/register.`