
# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/5.0/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-izo2-doms*!m$x=h4k8(f=x2ap!g-&eeom-#j-lff9wullnq#3'

GOOGLE_RECAPTCHA_SITE_KEY = '**********************' # Enter reCAPTCHA SITE key here...

GOOGLE_RECAPTCHA_SECRET_KEY = '**********************' # Enter reCAPTCHA SECRET key here...

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = ['*']


# Database
# https://docs.djangoproject.com/en/5.0/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'project_captcha',
        'USER': 'root',
        'PASSWORD': 'root'
    }
}
